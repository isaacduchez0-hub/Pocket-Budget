Pocket Budget PWA

Files:
- index.html
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png

Features:
- Mobile-first budget dashboard
- Monthly budget + category budgets
- Unlimited local transactions/categories in code
- Add / delete expenses
- CSV export
- Offline support after first load
- Shortcut URL parameter support:
  ?amount=12.50&category=Food%20%26%20Groceries&note=Coffee
  Add &auto=1 to save automatically without opening the form.

Important:
To install as an iPhone Home Screen web app, serve these files from an HTTPS website
(e.g. GitHub Pages, Netlify, Cloudflare Pages). Then open the site in Safari and use
Share > Add to Home Screen.
